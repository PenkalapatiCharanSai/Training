const Error = ()=>{
    return(
        <>
            <h1>Auth Fail : 404</h1>
        </>
    )
}
export default Error;