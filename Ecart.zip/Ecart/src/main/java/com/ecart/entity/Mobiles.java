package com.ecart.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Mobiles {
	
	@Id
	private int id;
	private String name;
	private double cost;
	private String image_url;
	private int qty;
	
	
}
